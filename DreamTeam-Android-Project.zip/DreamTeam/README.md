# DreamTeam Android WebView App

Native Android WebView wrapper for `https://dreamteamera.blogspot.com`.

## Build

Open this folder in Android Studio with an Android SDK installed, then run:

```text
Build > Generate App Bundles or APKs > Generate APKs > Generate Release APK
```

Or from a configured Gradle installation:

```bash
gradle :app:assembleRelease
```

The generated APK will be under:

```text
app/build/outputs/apk/release/app-release.apk
```

## Security behavior

- Blocks when Developer Options are enabled.
- Blocks Wi-Fi hotspot/tethering detection.
- Blocks an active Wi-Fi transport.
- Blocks any active VPN transport.
- Blocks common rooted/test-key devices.
- Uses `FLAG_SECURE`.
- Disables WebView file/content access.
- Uses `LOAD_NO_CACHE`.
- Clears WebView cache/history/form data and cookies before loading the site.
- Cancels invalid SSL connections.
- Never requests runtime permissions.
- Location/storage permissions are only checked when the website requests the corresponding capability.
- `android:allowBackup="false"` and cleartext traffic are disabled.

## Important

The current execution environment does not contain the Android SDK or Gradle distribution, so the APK cannot be compiled or runtime-tested inside this session. The project is complete and ready to build in Android Studio/Gradle with Android SDK 35.
