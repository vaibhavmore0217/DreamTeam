package com.dreamteam.app;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.Uri;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.CookieManager;
import android.webkit.GeolocationPermissions;
import android.webkit.SslErrorHandler;
import android.webkit.SslError;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceError;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebSettings;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.Space;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.lang.reflect.Method;
import java.net.NetworkInterface;
import java.util.Collections;
import java.util.List;

public class MainActivity extends Activity {
    private static final String HOME_URL = "https://dreamteamera.blogspot.com";
    private static final int FILE_CHOOSER_REQUEST = 4101;

    private FrameLayout root;
    private WebView webView;
    private LinearLayout navBar;
    private ValueCallback<Uri[]> filePathCallback;

    private static final class AuditResult {
        boolean developerOptions;
        boolean hotspot;
        boolean wifi;
        boolean vpn;
        boolean root;
        boolean allPassed() {
            return !developerOptions && !hotspot && !wifi && !vpn && !root;
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeatures(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_SECURE | WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_SECURE | WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().setNavigationBarColor(Color.BLACK);
        showAuditScreen();
        runAudits();
    }

    private void showAuditScreen() {
        root = new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(10, 11, 14));

        LinearLayout center = new LinearLayout(this);
        center.setOrientation(LinearLayout.VERTICAL);
        center.setGravity(Gravity.CENTER_HORIZONTAL);
        center.setPadding(dp(28), dp(30), dp(28), dp(30));
        GradientDrawable cardBg = new GradientDrawable();
        cardBg.setColor(Color.rgb(25, 27, 32));
        cardBg.setCornerRadius(dp(22));
        center.setBackground(cardBg);
        center.setElevation(dp(10));

        FrameLayout.LayoutParams cp = new FrameLayout.LayoutParams(dp(330), dp(245), Gravity.CENTER);
        cp.setMargins(dp(18), dp(18), dp(18), dp(18));
        root.addView(center, cp);

        TextView lock = new TextView(this);
        lock.setText("🔒");
        lock.setTextSize(42);
        lock.setGravity(Gravity.CENTER);
        center.addView(lock, new LinearLayout.LayoutParams(-1, dp(70)));

        TextView title = new TextView(this);
        title.setText("DreamTeam");
        title.setTextColor(Color.WHITE);
        title.setTextSize(25);
        title.setGravity(Gravity.CENTER);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        center.addView(title, new LinearLayout.LayoutParams(-1, dp(42)));

        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(15), dp(12), dp(15), dp(12));
        ProgressBar spinner = new ProgressBar(this);
        spinner.setIndeterminate(true);
        row.addView(spinner, new LinearLayout.LayoutParams(dp(28), dp(28)));
        TextView text = new TextView(this);
        text.setText("Performing secure system audits...");
        text.setTextColor(Color.rgb(210, 214, 220));
        text.setTextSize(14);
        text.setPadding(dp(12), 0, 0, 0);
        row.addView(text, new LinearLayout.LayoutParams(0, dp(52), 1));
        center.addView(row, new LinearLayout.LayoutParams(-1, dp(70)));

        setContentView(root);
    }

    private void runAudits() {
        new Thread(() -> {
            AuditResult result = performAudits();
            runOnUiThread(() -> {
                if (result.allPassed()) {
                    showMainScreen();
                } else {
                    showSecurityDashboard(result);
                }
            });
        }, "DreamTeam-SecurityAudit").start();
    }

    private AuditResult performAudits() {
        AuditResult r = new AuditResult();
        r.developerOptions = isDeveloperOptionsEnabled();
        r.hotspot = isHotspotEnabled();
        r.wifi = isWifiConnected();
        r.vpn = isVpnConnected();
        r.root = isDeviceRooted();
        return r;
    }

    private boolean isDeveloperOptionsEnabled() {
        try {
            return Settings.Global.getInt(getContentResolver(), Settings.Global.DEVELOPMENT_SETTINGS_ENABLED, 0) == 1;
        } catch (Exception e) {
            return false;
        }
    }

    @SuppressLint("PrivateApi")
    private boolean isHotspotEnabled() {
        boolean reflectionResult = false;
        try {
            WifiManager wm = (WifiManager) getApplicationContext().getSystemService(WIFI_SERVICE);
            Method method = wm.getClass().getDeclaredMethod("isWifiApEnabled");
            method.setAccessible(true);
            Object value = method.invoke(wm);
            reflectionResult = value instanceof Boolean && (Boolean) value;
        } catch (Throwable ignored) {
        }
        if (reflectionResult) return true;

        try {
            for (NetworkInterface ni : Collections.list(NetworkInterface.getNetworkInterfaces())) {
                String n = ni.getName();
                if (n == null) continue;
                String name = n.toLowerCase(java.util.Locale.US);
                if ((name.equals("ap0") || name.startsWith("ap") || name.startsWith("softap") || name.equals("wlan1")) && ni.isUp()) {
                    return true;
                }
            }
        } catch (Throwable ignored) {
        }
        return false;
    }

    private boolean isWifiConnected() {
        ConnectivityManager cm = (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
        if (cm == null) return false;
        try {
            Network active = cm.getActiveNetwork();
            if (active != null) {
                NetworkCapabilities caps = cm.getNetworkCapabilities(active);
                return caps != null && caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI);
            }
        } catch (SecurityException ignored) {
        }
        return false;
    }

    private boolean isVpnConnected() {
        ConnectivityManager cm = (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
        if (cm == null) return false;
        try {
            Network active = cm.getActiveNetwork();
            if (active != null) {
                NetworkCapabilities caps = cm.getNetworkCapabilities(active);
                if (caps != null && caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN)) return true;
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                for (Network network : cm.getAllNetworks()) {
                    NetworkCapabilities caps = cm.getNetworkCapabilities(network);
                    if (caps != null && caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN)) return true;
                }
            }
        } catch (SecurityException ignored) {
        }
        return false;
    }

    private boolean isDeviceRooted() {
        String tags = Build.TAGS;
        if (tags != null && tags.contains("test-keys")) return true;
        String[] paths = {
                "/system/bin/su", "/system/xbin/su", "/sbin/su", "/data/local/su",
                "/data/local/bin/su", "/data/local/xbin/su", "/system/app/Superuser.apk",
                "/system/bin/.ext/.su", "/system/xbin/daemonsu", "/system/usr/we-need-root/su",
                "/data/adb/su", "/data/adb/magisk", "/cache/su", "/dev/com.koushikdutta.superuser.daemon/"
        };
        for (String path : paths) {
            try {
                if (new File(path).exists()) return true;
            } catch (Throwable ignored) {
            }
        }
        return false;
    }

    private void showSecurityDashboard(AuditResult r) {
        root = new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(10, 11, 14));

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(20), dp(35), dp(20), dp(25));
        scroll.addView(content, new ScrollView.LayoutParams(-1, -2));
        root.addView(scroll, new FrameLayout.LayoutParams(-1, -1));

        TextView title = new TextView(this);
        title.setText("Security Check Required");
        title.setTextColor(Color.WHITE);
        title.setTextSize(25);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        content.addView(title, new LinearLayout.LayoutParams(-1, dp(42)));

        TextView sub = new TextView(this);
        sub.setText("DreamTeam access is blocked until every security check passes.");
        sub.setTextColor(Color.rgb(165, 170, 180));
        sub.setTextSize(14);
        sub.setPadding(0, 0, 0, dp(18));
        content.addView(sub, new LinearLayout.LayoutParams(-1, -2));

        addCheckCard(content, "Developer Options", r.developerOptions);
        addCheckCard(content, "Wi-Fi Hotspot", r.hotspot);
        addCheckCard(content, "Wi-Fi Connection", r.wifi);
        addCheckCard(content, "VPN Connection", r.vpn);
        addCheckCard(content, "Root Detection", r.root);

        Space space = new Space(this);
        content.addView(space, new LinearLayout.LayoutParams(1, dp(14)));
        Button retry = new Button(this);
        retry.setText("Retry");
        retry.setAllCaps(false);
        retry.setTextSize(16);
        retry.setOnClickListener(v -> {
            showAuditScreen();
            runAudits();
        });
        content.addView(retry, new LinearLayout.LayoutParams(-1, dp(52)));
        setContentView(root);
    }

    private void addCheckCard(LinearLayout parent, String name, boolean failed) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.HORIZONTAL);
        card.setGravity(Gravity.CENTER_VERTICAL);
        card.setPadding(dp(16), dp(13), dp(16), dp(13));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.rgb(25, 27, 32));
        bg.setCornerRadius(dp(15));
        card.setBackground(bg);
        TextView label = new TextView(this);
        label.setText(name);
        label.setTextColor(Color.WHITE);
        label.setTextSize(15);
        label.setTypeface(null, android.graphics.Typeface.BOLD);
        card.addView(label, new LinearLayout.LayoutParams(0, dp(58), 1));

        TextView status = new TextView(this);
        status.setText(failed ? "ON - Please disable" : "OFF");
        status.setTextColor(Color.WHITE);
        status.setTextSize(13);
        status.setGravity(Gravity.CENTER);
        GradientDrawable sbg = new GradientDrawable();
        sbg.setColor(failed ? Color.rgb(185, 35, 45) : Color.rgb(25, 135, 75));
        sbg.setCornerRadius(dp(12));
        status.setBackground(sbg);
        card.addView(status, new LinearLayout.LayoutParams(dp(145), dp(42)));
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, dp(76));
        cp.bottomMargin = dp(10);
        parent.addView(card, cp);
    }

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    private void showMainScreen() {
        root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);

        LinearLayout main = new LinearLayout(this);
        main.setOrientation(LinearLayout.VERTICAL);
        root.addView(main, new FrameLayout.LayoutParams(-1, -1));

        webView = new WebView(this);
        webView.setBackgroundColor(Color.BLACK);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setCacheMode(WebSettings.LOAD_NO_CACHE);
        s.setSaveFormData(false);
        s.setSavePassword(false);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setGeolocationEnabled(true);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        }
        webView.setWebViewClient(new SecureWebViewClient());
        webView.setWebChromeClient(new SecureChromeClient());
        main.addView(webView, new LinearLayout.LayoutParams(-1, 0, 1));

        navBar = buildNavigationBar();
        main.addView(navBar, new LinearLayout.LayoutParams(-1, dp(58)));
        setContentView(root);

        clearSessionThenLoadHome();
    }

    private LinearLayout buildNavigationBar() {
        LinearLayout bar = new LinearLayout(this);
        bar.setGravity(Gravity.CENTER);
        bar.setBackgroundColor(Color.rgb(12, 12, 14));
        bar.setPadding(dp(8), dp(5), dp(8), dp(5));

        TextView back = navButton("‹", "Back");
        back.setOnClickListener(v -> handleBack());
        TextView home = navButton("⌂", "Home");
        home.setOnClickListener(v -> webView.loadUrl(HOME_URL));
        TextView menu = navButton("⋮", "Menu");
        menu.setOnClickListener(this::showMenu);
        bar.addView(back, new LinearLayout.LayoutParams(0, -1, 1));
        bar.addView(home, new LinearLayout.LayoutParams(0, -1, 1));
        bar.addView(menu, new LinearLayout.LayoutParams(0, -1, 1));
        return bar;
    }

    private TextView navButton(String symbol, String description) {
        TextView v = new TextView(this);
        v.setText(symbol);
        v.setContentDescription(description);
        v.setTextColor(Color.WHITE);
        v.setTextSize(30);
        v.setGravity(Gravity.CENTER);
        v.setBackgroundColor(Color.TRANSPARENT);
        return v;
    }

    private void showMenu(View anchor) {
        PopupMenu pm = new PopupMenu(this, anchor);
        pm.getMenu().add("Refresh Page");
        pm.getMenu().add("Clear Session");
        pm.getMenu().add("Exit Application");
        pm.setOnMenuItemClickListener(item -> {
            String x = item.getTitle().toString();
            if (x.equals("Refresh Page")) {
                webView.reload();
                return true;
            }
            if (x.equals("Clear Session")) {
                clearSessionThenLoadHome();
                return true;
            }
            if (x.equals("Exit Application")) {
                finishAndRemoveTask();
                return true;
            }
            return false;
        });
        pm.show();
    }

    private void handleBack() {
        if (webView == null) return;
        if (webView.canGoBack()) {
            webView.goBack();
        } else if (isHomeUrl(webView.getUrl())) {
            finishAndRemoveTask();
        } else {
            webView.loadUrl(HOME_URL);
        }
    }

    private boolean isHomeUrl(String url) {
        if (url == null) return false;
        String normalized = url.endsWith("/") ? url.substring(0, url.length() - 1) : url;
        return normalized.equals(HOME_URL);
    }

    private void clearSessionThenLoadHome() {
        if (webView == null) return;
        webView.stopLoading();
        webView.clearCache(true);
        webView.clearHistory();
        webView.clearFormData();
        CookieManager cm = CookieManager.getInstance();
        cm.removeAllCookies(value -> {
            cm.flush();
            runOnUiThread(() -> webView.loadUrl(HOME_URL));
        });
        cm.flush();
    }

    private boolean hasLocationPermission() {
        return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
                || checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    private boolean hasStoragePermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            return checkSelfPermission(Manifest.permission.READ_MEDIA_IMAGES) == PackageManager.PERMISSION_GRANTED;
        }
        return checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED;
    }

    private void showShort(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    private class SecureWebViewClient extends WebViewClient {
        @Override public void onReceivedSslError(WebView view, SslErrorHandler handler, SslError error) {
            handler.cancel();
        }
        @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
            if (request == null || request.getUrl() == null) return true;
            Uri u = request.getUrl();
            String scheme = u.getScheme();
            if ("https".equalsIgnoreCase(scheme) || "http".equalsIgnoreCase(scheme)) {
                view.loadUrl(u.toString());
                return true;
            }
            try {
                startActivity(new Intent(Intent.ACTION_VIEW, u));
            } catch (Exception ignored) {}
            return true;
        }
        @Override public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
            super.onReceivedError(view, request, error);
        }
    }

    private class SecureChromeClient extends WebChromeClient {
        @Override public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback callback) {
            if (hasLocationPermission()) {
                callback.invoke(origin, true, false);
            } else {
                callback.invoke(origin, false, false);
                showShort("Location permission is off. Enable it from App Settings.");
            }
        }

        @Override public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> callback, FileChooserParams params) {
            if (filePathCallback != null) filePathCallback.onReceiveValue(null);
            filePathCallback = callback;
            if (!hasStoragePermission()) {
                filePathCallback = null;
                callback.onReceiveValue(null);
                showShort("Storage permission is off. Enable it from App Settings.");
                return true;
            }
            try {
                Intent intent = params.createIntent();
                startActivityForResult(intent, FILE_CHOOSER_REQUEST);
                return true;
            } catch (Exception e) {
                filePathCallback = null;
                callback.onReceiveValue(null);
                return true;
            }
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_CHOOSER_REQUEST && filePathCallback != null) {
            Uri[] results = null;
            if (resultCode == RESULT_OK && data != null) {
                if (data.getClipData() != null) {
                    int count = data.getClipData().getItemCount();
                    results = new Uri[count];
                    for (int i = 0; i < count; i++) results[i] = data.getClipData().getItemAt(i).getUri();
                } else if (data.getData() != null) {
                    results = new Uri[]{data.getData()};
                }
            }
            filePathCallback.onReceiveValue(results);
            filePathCallback = null;
        }
    }

    @Override public void onBackPressed() {
        handleBack();
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
